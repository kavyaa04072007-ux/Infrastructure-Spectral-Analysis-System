"""
MFC Project: Infrastructure Network Spectral Analysis Server
============================================================
Mathematical foundations (MFC topics):
  - Graph Laplacian matrix: L = D - A
  - Eigenvalue decomposition of L
  - Fiedler value (2nd smallest eigenvalue) → algebraic connectivity
  - Principal eigenvector centrality (spectral centrality)
  - Spectral gap analysis
  - Betweenness centrality (graph traversal)
  - Biconnected components / articulation points (single points of failure)
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import networkx as nx
import numpy as np
from scipy.linalg import eigh  # symmetric eigendecomposition (Laplacian is symmetric)

app = Flask(__name__)
CORS(app)


# ─────────────────────────────────────────────
#  Core Math: Spectral Analysis
# ─────────────────────────────────────────────

def build_graph(nodes, edges):
    """Build a NetworkX graph from frontend data."""
    G = nx.Graph()
    for n in nodes:
        G.add_node(n["id"], label=n.get("label", str(n["id"])))
    for e in edges:
        w = e.get("weight", 1.0)
        G.add_edge(e["source"], e["target"], weight=w)
    return G


def laplacian_spectral_analysis(G):
    """
    Core MFC math:
    1. Adjacency matrix A (weighted)
    2. Degree matrix D
    3. Laplacian L = D - A
    4. Eigendecomposition of L → eigenvalues λ, eigenvectors v
    5. Fiedler value = λ₂ (2nd smallest) → algebraic connectivity
    6. Spectral gap = λ₂ / λ_max → network robustness ratio
    7. Spectral centrality from principal eigenvector of A
    """
    node_list = list(G.nodes())
    n = len(node_list)

    if n == 0:
        return {}

    # Weighted adjacency matrix
    A = nx.to_numpy_array(G, nodelist=node_list, weight="weight")

    # Degree matrix (weighted degree = row sums)
    D = np.diag(A.sum(axis=1))

    # Graph Laplacian
    L = D - A

    # Eigendecomposition of L (real symmetric → use eigh for stability)
    eigenvalues, eigenvectors = eigh(L)
    # eigenvalues are sorted ascending by eigh

    # Algebraic connectivity (Fiedler value) = 2nd smallest eigenvalue
    fiedler_value = float(eigenvalues[1]) if n > 1 else 0.0

    # Spectral gap = fiedler / max_eigenvalue
    lambda_max = float(eigenvalues[-1]) if eigenvalues[-1] != 0 else 1.0
    spectral_gap = fiedler_value / lambda_max if lambda_max != 0 else 0.0

    # Fiedler vector (eigenvector for λ₂) → identifies weakly connected subgraphs
    fiedler_vector = eigenvectors[:, 1] if n > 1 else eigenvectors[:, 0]
    fiedler_map = {node_list[i]: float(fiedler_vector[i]) for i in range(n)}

    # ── Spectral centrality from adjacency matrix ──
    # Use principal eigenvector of A (largest eigenvalue)
    eig_vals_A, eig_vecs_A = np.linalg.eigh(A)
    principal_vec = np.abs(eig_vecs_A[:, -1])  # eigenvector for max eigenvalue
    principal_vec = principal_vec / (principal_vec.sum() + 1e-12)
    spectral_centrality = {node_list[i]: float(principal_vec[i]) for i in range(n)}

    # ── Betweenness centrality ──
    betweenness = nx.betweenness_centrality(G, weight="weight", normalized=True)

    # ── Degree (weighted) ──
    weighted_degree = dict(G.degree(weight="weight"))
    max_deg = max(weighted_degree.values()) if weighted_degree else 1
    normalized_degree = {k: v / max_deg for k, v in weighted_degree.items()}

    # ── Articulation points (single points of failure) ──
    articulation_pts = set(nx.articulation_points(G)) if G.number_of_nodes() > 1 else set()

    # ── Combined risk score per node ──
    # Risk = weighted combination of spectral centrality + betweenness + normalized degree
    risk_scores = {}
    for node in node_list:
        sc = spectral_centrality.get(node, 0)
        bc = betweenness.get(node, 0)
        nd = normalized_degree.get(node, 0)
        is_ap = 1.0 if node in articulation_pts else 0.0
        # MFC-justified formula: composite criticality
        risk = 0.35 * sc + 0.35 * bc + 0.15 * nd + 0.15 * is_ap
        risk_scores[node] = round(risk, 4)

    # ── Classify nodes ──
    max_risk = max(risk_scores.values()) if risk_scores else 0
    node_classification = {}
    for node, risk in risk_scores.items():
        is_ap = node in articulation_pts
        if risk >= 0.7 * max_risk and max_risk > 0.05:
            cls = "critical"
        elif risk >= 0.4 * max_risk and max_risk > 0.02:
            cls = "high"
        elif is_ap:
            cls = "high"  # articulation point = at least high risk
        else:
            cls = "normal"
        node_classification[node] = cls

    # ── Edge stress ──
    # Edges connecting high-degree or critical nodes carry more stress
    edge_stress = {}
    for u, v, data in G.edges(data=True):
        stress = (risk_scores.get(u, 0) + risk_scores.get(v, 0)) / 2.0
        edge_stress[f"{u}_{v}"] = round(stress, 4)

    # ── Overall system health ──
    # Fiedler > 0.5 → well connected, near 0 → about to disconnect
    if not nx.is_connected(G):
        connectivity_status = "disconnected"
        health_score = 0.0
    elif fiedler_value < 0.05:
        connectivity_status = "fragile"
        health_score = round(fiedler_value * 5, 3)
    elif fiedler_value < 0.3:
        connectivity_status = "moderate"
        health_score = round(0.25 + fiedler_value * 2, 3)
    else:
        connectivity_status = "robust"
        health_score = min(1.0, round(0.5 + spectral_gap, 3))

    # ── Biconnected components count ──
    biconnected = list(nx.biconnected_components(G))
    num_biconnected = len(biconnected)

    return {
        "fiedler_value": round(fiedler_value, 4),
        "spectral_gap": round(spectral_gap, 4),
        "lambda_max": round(lambda_max, 4),
        "algebraic_connectivity_interpretation": (
            "Well connected — network can lose nodes and stay intact"
            if fiedler_value > 0.3 else
            "Weakly connected — vulnerable to targeted removal"
            if fiedler_value > 0.05 else
            "Near-disconnected — any removal may split the network"
        ),
        "spectral_centrality": {str(k): v for k, v in spectral_centrality.items()},
        "betweenness_centrality": {str(k): round(v, 4) for k, v in betweenness.items()},
        "fiedler_vector": {str(k): round(v, 4) for k, v in fiedler_map.items()},
        "risk_scores": {str(k): v for k, v in risk_scores.items()},
        "node_classification": {str(k): v for k, v in node_classification.items()},
        "edge_stress": edge_stress,
        "articulation_points": [str(a) for a in articulation_pts],
        "connectivity_status": connectivity_status,
        "health_score": health_score,
        "num_biconnected_components": num_biconnected,
        "num_nodes": n,
        "num_edges": G.number_of_edges(),
        "is_connected": nx.is_connected(G),
        "recommendations": generate_recommendations(
            G, fiedler_value, articulation_pts, node_classification, spectral_gap, health_score
        )
    }


def generate_recommendations(G, fiedler_value, articulation_pts, node_classification, spectral_gap, health_score):
    recs = []

    if not nx.is_connected(G):
        recs.append({
            "type": "error",
            "icon": "⛔",
            "title": "Network is Disconnected",
            "detail": "Your graph has isolated components. All nodes must be reachable from each other for a functional infrastructure."
        })
        return recs

    critical_nodes = [n for n, c in node_classification.items() if c == "critical"]
    if articulation_pts:
        recs.append({
            "type": "critical",
            "icon": "🔴",
            "title": f"Single Points of Failure Detected ({len(articulation_pts)} node{'s' if len(articulation_pts)>1 else ''})",
            "detail": f"Nodes {', '.join(str(a) for a in articulation_pts)} are articulation points. Removing any one of them splits the network. Add redundant paths around these nodes."
        })

    if fiedler_value < 0.1 and nx.is_connected(G):
        recs.append({
            "type": "warning",
            "icon": "🟠",
            "title": "Low Algebraic Connectivity (λ₂ = {:.4f})".format(fiedler_value),
            "detail": "The Fiedler value is near zero, indicating the graph is close to splitting. Strengthen cross-cluster connections to improve spectral gap."
        })

    if len(critical_nodes) > 0:
        recs.append({
            "type": "warning",
            "icon": "🟡",
            "title": f"High-Centrality Nodes: {', '.join(critical_nodes)}",
            "detail": "These nodes have disproportionate influence on network flow. Consider adding parallel paths or redistributing traffic load."
        })

    if G.number_of_nodes() > 3 and G.number_of_edges() < G.number_of_nodes() - 1 + 1:
        recs.append({
            "type": "info",
            "icon": "🔵",
            "title": "Low Edge Density",
            "detail": "Your network has few edges relative to nodes. More connections increase spectral gap and reduce vulnerability."
        })

    if health_score > 0.75:
        recs.append({
            "type": "success",
            "icon": "🟢",
            "title": "Network Topology is Robust",
            "detail": f"Spectral gap = {spectral_gap:.4f}. The infrastructure design shows good fault tolerance and load distribution."
        })

    if not recs:
        recs.append({
            "type": "info",
            "icon": "🔵",
            "title": "Add more nodes and edges for deeper analysis",
            "detail": "Build a more complex topology to trigger spectral insights. Try creating a hub-spoke or ring topology."
        })

    return recs


# ─────────────────────────────────────────────
#  API Routes
# ─────────────────────────────────────────────

@app.route("/analyze", methods=["POST"])
def analyze():
    data = request.get_json()
    nodes = data.get("nodes", [])
    edges = data.get("edges", [])

    if len(nodes) < 2:
        return jsonify({"error": "Need at least 2 nodes to analyze."}), 400

    G = build_graph(nodes, edges)
    result = laplacian_spectral_analysis(G)
    return jsonify(result)


@app.route("/ping", methods=["GET"])
def ping():
    return jsonify({"status": "ok", "message": "MFC Spectral Analysis Server running"})


if __name__ == "__main__":
    print("=" * 55)
    print("  MFC Infrastructure Spectral Analysis Server")
    print("  http://localhost:5050")
    print("  Open index.html in your browser to start")
    print("=" * 55)
    app.run(port=5050, debug=False)
